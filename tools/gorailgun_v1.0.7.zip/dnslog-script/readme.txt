各个脚本注意事项：
1.dnslog-ping.pl 使用ping命令解析域名，不用nslookup是为了防止有的环境没有，但ping是肯定有的
2.dnslog-resolve.ps1 使用 [System.Net.DNS]模块进行域名解析
3.dnslog-resolve.py 使用socket.gethostbyname解析域名
4.dnslog-ping.ps1 使用ping命令解析域名
5.dnslog-ping-timeout.ps1 使用ping命令解析域名，但加了超时时间，防止解析太久

推荐使用1/2/3测试